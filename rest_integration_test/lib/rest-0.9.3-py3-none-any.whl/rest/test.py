import rest.configure as conf

if __name__ == '__main__':
    conf.Configure()
