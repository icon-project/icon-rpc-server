# -*- coding: utf-8 -*-

# Copyright 2017-2018 theloop Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from struct import Struct
from ..icon_config import DATA_BYTE_ORDER, DEFAULT_BYTE_SIZE
from typing import Optional


class Block(object):
    """Block Information included in IconScoreContext
    """
    _VERSION = 0
    # leveldb account value structure (bigendian, 1 + 32 + 32 + 32 + 32 bytes)
    # version(1)
    # | height(DEFAULT_BYTE_SIZE)
    # | hash(DEFAULT_BYTE_SIZE)
    # | timestamp(DEFAULT_BYTE_SIZE)
    # | prev_hash(DEFAULT_BYTE_SIZE)

    _struct = Struct(f'>c{DEFAULT_BYTE_SIZE}s{DEFAULT_BYTE_SIZE}s{DEFAULT_BYTE_SIZE}s{DEFAULT_BYTE_SIZE}s')

    def __init__(self, block_height: int, block_hash: bytes, timestamp: int, prev_hash: Optional[bytes]) -> None:
        """Constructor

        :param block_height: block height
        :param block_hash: block hash
        :param timestamp: block timestamp
        :param prev_hash: prev block hash
        """
        self._height = block_height
        self._hash = block_hash
        # unit: microsecond
        self._timestamp = timestamp
        self._prev_hash = prev_hash

    @property
    def height(self) -> int:
        return self._height

    @property
    def hash(self) -> bytes:
        return self._hash

    @property
    def timestamp(self) -> int:
        return self._timestamp

    @property
    def prev_hash(self) -> bytes:
        return self._prev_hash

    @staticmethod
    def from_dict(params: dict):
        block_height = params.get('blockHeight')
        block_hash = params.get('blockHash')
        timestamp = params.get('timestamp')
        prev_hash = params.get('prevBlockHash')
        return Block(block_height, block_hash, timestamp, prev_hash)

    @staticmethod
    def from_block(block: 'Block'):
        block_height = block.height
        block_hash = block.hash
        timestamp = block.timestamp
        prev_hash = block.prev_hash
        return Block(block_height, block_hash, timestamp, prev_hash)

    @staticmethod
    def from_bytes(buf: bytes) -> 'Block':
        """Create Account object from bytes data

        :param buf: (bytes) bytes data including Account information
        :return: (Account) account object
        """
        byteorder = DATA_BYTE_ORDER

        version_bytes, block_height_bytes, block_hash_bytes, timestamp_bytes, block_prev_hash_bytes = \
            Block._struct.unpack(buf)

        # version = int.from_bytes(version_bytes, byteorder)
        block_height = int.from_bytes(block_height_bytes, byteorder)
        block_hash = block_hash_bytes
        timestamp = int.from_bytes(timestamp_bytes, byteorder)
        byte_prev_hash = block_prev_hash_bytes

        if int(bytes.hex(byte_prev_hash), 16) == 0:
            byte_prev_hash = None
        prev_block_hash = byte_prev_hash

        block = Block(block_height, block_hash, timestamp, prev_block_hash)
        return block

    def to_bytes(self) -> bytes:
        """Convert block object to bytes

        :return: data including information of block object
        """

        byteorder = DATA_BYTE_ORDER
        # for extendability
        version_bytes = self._VERSION.to_bytes(1, byteorder)
        block_height_bytes = self._height.to_bytes(DEFAULT_BYTE_SIZE, byteorder)
        block_hash_bytes = self._hash
        timestamp_bytes = self._timestamp.to_bytes(DEFAULT_BYTE_SIZE, byteorder)

        tmp_prev_hash = self._prev_hash
        if tmp_prev_hash is None:
            tmp_prev_hash = bytes(DEFAULT_BYTE_SIZE)
        prev_block_hash_bytes = tmp_prev_hash

        return Block._struct.pack(
            version_bytes,
            block_height_bytes,
            block_hash_bytes,
            timestamp_bytes,
            prev_block_hash_bytes)

    def __bytes__(self) -> bytes:
        """operator bytes() overriding

        :return: binary data including information of account object
        """
        return self.to_bytes()
