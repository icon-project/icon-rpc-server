# Copyright 2017 theloop Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""A stub wrapper for REST call.
This object has same interface with gRPC stub manager"""

import logging

from concurrent.futures import ThreadPoolExecutor
from jsonrpcclient.http_client import HTTPClient

import loopchain.utils as util
from loopchain import configure as conf


class RestStubManager:
    def __init__(self, target):
        util.logger.spam(f"RestStubManager:init target({target})")
        self.__target = target
        self.__request_url = f"{'https' if conf.SUBSCRIBE_USE_HTTPS else 'http'}://{target}/api/node/"
        self.__executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="RestStubThread")

    @property
    def target(self):
        return self.__target

    @staticmethod
    def __method_name_converter(method_name):
        if method_name in ["Subscribe", "Unsubscribe", "GetChannelInfos", "AnnounceConfirmedBlock"]:
            method_name = f"node_{method_name}"

        return method_name

    def call(self, method_name, message, timeout=None, is_stub_reuse=True, is_raise=False):
        try:
            response = HTTPClient(self.__request_url).request(method_name=self.__method_name_converter(method_name),
                                                              message=message)
            util.logger.spam(f"RestStubManager:call complete request_url({self.__request_url}), "
                             f"method_name({method_name}), response({response})")
            return response
        except Exception as e:
            logging.warning(f"REST call fail method_name({method_name}), caused by : {e}")
            raise e

    def call_async(self, method_name, message, call_back=None, timeout=None, is_stub_reuse=True):
        future = self.__executor.submit(self.call, method_name, message, timeout, is_stub_reuse)
        if call_back:
            future.add_done_callback(call_back)
        return future

    def call_in_time(self, method_name, message, time_out_seconds=None, is_stub_reuse=True):
        """Try gRPC call. If it fails try again until time out (seconds)

        :param method_name:
        :param message:
        :param time_out_seconds:
        :param is_stub_reuse:
        :return:
        """
        method_name_ = self.__method_name_converter(method_name)
        util.logger.spam(f"RestStubManager:call_in_time {method_name_}")
        return None

    def call_in_times(self, method_name, message,
                      retry_times=None,
                      is_stub_reuse=True,
                      timeout=conf.GRPC_TIMEOUT):
        """Try gRPC call. If it fails try again until "retry_times"

        :param method_name:
        :param message:
        :param retry_times:
        :param is_stub_reuse:
        :param timeout:
        :return:
        """
        response = HTTPClient(self.__request_url).request(
            method_name=self.__method_name_converter(method_name), message=message)
        util.logger.spam(f"RestStubManager:call_in_times {method_name} response({response})")
        return response
