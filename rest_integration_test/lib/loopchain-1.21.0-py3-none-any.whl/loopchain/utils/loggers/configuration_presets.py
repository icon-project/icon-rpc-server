# Copyright [theloop]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import verboselogs

from enum import Enum
from loopchain import configure as conf
from loopchain.utils.loggers.configuration import LogConfiguration


develop = LogConfiguration()
develop.log_format = conf.LOG_FORMAT_DEBUG
develop.log_level = verboselogs.SPAM
develop.log_color = True
develop.log_file_path = conf.LOG_FILE_PATH
develop.log_monitor = conf.MONITOR_LOG
develop.log_monitor_host = conf.MONITOR_LOG_HOST
develop.log_monitor_port = conf.MONITOR_LOG_PORT

production = LogConfiguration()
production.log_format = conf.LOG_FORMAT
production.log_level = conf.LOG_LEVEL
production.log_color = False
production.log_file_path = conf.LOG_FILE_PATH
production.log_monitor = conf.MONITOR_LOG
production.log_monitor_host = conf.MONITOR_LOG_HOST
production.log_monitor_port = conf.MONITOR_LOG_PORT


class Preset(Enum):
    develop = 0
    production = 1


_preset = Preset.production
_presets = {
    Preset.develop: develop,
    Preset.production: production
}


def set_preset(preset):
    global _preset
    _preset = preset


def get_preset():
    return _presets[_preset]
