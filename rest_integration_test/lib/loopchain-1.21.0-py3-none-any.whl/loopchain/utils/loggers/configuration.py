# Copyright [theloop]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import coloredlogs
import verboselogs

from fluent import sender


class LogConfiguration:
    def __init__(self):
        self.log_format = None
        self.peer_id = ""
        self.channel_name = ""
        self.score_package = ""
        self.log_level = verboselogs.SPAM
        self.log_color = True
        self.log_file_path = None
        self.log_monitor = False
        self.log_monitor_host = None
        self.log_monitor_port = None
        self.is_leader = False

        self._log_format = None

    def update_logger(self, logger: logging.Logger=None):
        if logger is None:
            logger = logging.root

        self._log_format = self.log_format.replace("[PEER_ID]", self.peer_id)
        self._log_format = self._log_format.replace("[CHANNEL_NAME]", self.channel_name)

        score_package_format = f"({self.score_package})" if self.score_package else ""
        self._log_format = self._log_format.replace("[SCORE_PACKAGE]", score_package_format)

        for handler in logger.handlers[:]:
            logger.removeHandler(handler)

        if logger is logging.root:
            stream_handler = logging.StreamHandler()
            stream_handler.level = self.log_level
            file_handler = logging.FileHandler(self.log_file_path, 'w', 'utf-8')

            logging.basicConfig(handlers=[file_handler, stream_handler],
                                format=self._log_format,
                                datefmt="%m%d %H:%M:%S",
                                level=self.log_level)

            if self.log_color:
                self._update_log_color_set(logger)
        else:
            logger.setLevel(self.log_level)

        if self.log_monitor:
            sender.setup('loopchain', host=self.log_monitor_host, port=self.log_monitor_port)

    def _update_log_color_set(self, logger):
        # level SPAM value is 5
        # level DEBUG value is 10
        coloredlogs.DEFAULT_FIELD_STYLES = {
            'hostname': {'color': 'magenta'},
            'programname': {'color': 'cyan'},
            'name': {'color': 'blue'},
            'levelname': {'color': 'black', 'bold': True},
            'asctime': {'color': 'magenta'}}

        if self.is_leader:
            coloredlogs.DEFAULT_LEVEL_STYLES = {
                'info': {},
                'notice': {'color': 'magenta'},
                'verbose': {'color': 'green'},
                'success': {'color': 'green', 'bold': True},
                'spam': {'color': 'cyan'},
                'critical': {'color': 'red', 'bold': True},
                'error': {'color': 'red'},
                'debug': {'color': 'blue'},
                'warning': {'color': 'yellow'}}
        else:
            coloredlogs.DEFAULT_LEVEL_STYLES = {
                'info': {},
                'notice': {'color': 'magenta'},
                'verbose': {'color': 'blue'},
                'success': {'color': 'green', 'bold': True},
                'spam': {'color': 'cyan'},
                'critical': {'color': 'red', 'bold': True},
                'error': {'color': 'red'},
                'debug': {'color': 'green'},
                'warning': {'color': 'yellow'}}

        coloredlogs.install(logger=logger,
                            fmt=self._log_format,
                            datefmt="%m%d %H:%M:%S",
                            level=self.log_level,
                            milliseconds=True)
