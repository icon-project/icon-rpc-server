#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright 2017 theloop Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import logging
import os

import loopchain.utils as util
from loopchain import configure as conf
from loopchain.peer import PeerService
from loopchain.radiostation import RadioStationService
from loopchain.rest_server.rest_server import ServerComponents, PeerServiceStub
from loopchain.rest_server.rest_server_rs import ServerComponents as RSServerComponents
from loopchain.scoreservice import ScoreService
from loopchain.blockchain import tx_validator
from loopchain.channel.channel_service import ChannelService
from loopchain.tools.grpc_helper import grpc_patcher
from loopchain.utils import loggers, command_arguments, async


def main(argv):
    parser = argparse.ArgumentParser()
    for cmd_arg_type in command_arguments.Type:
        cmd_arg_attr = command_arguments.attributes[cmd_arg_type]
        parser.add_argument(*cmd_arg_attr.names, **cmd_arg_attr.kwargs)

    args = parser.parse_args(argv)
    command_arguments.set_raw_commands(args)

    if args.configure_file_path:
        conf.Configure().load_configure_json(args.configure_file_path)

    if args.develop:
        loggers.set_preset(loggers.Preset.develop)
    else:
        loggers.set_preset(loggers.Preset.production)
    loggers.get_preset().update_logger()
    loggers.update_other_loggers()

    grpc_patcher.monkey_patch()
    async.thread_monkey_patch()
    async.concurrent_future_monkey_patch()
    tx_validator.refresh_validators()

    if args.service_type == "peer":
        start_as_peer(args, conf.NodeType.CommunityNode)
    elif args.service_type == "citizen":
        start_as_peer(args, conf.NodeType.CitizenNode)
    elif args.service_type == "rs" or args.service_type == "radiostation":
        start_as_rs(args)
    elif args.service_type == "rest":
        start_as_rest_server(args)
    elif args.service_type == "rest-rs":
        start_as_rest_server_rs(args)
    elif args.service_type == "score":
        start_as_score(args)
    elif args.service_type == "channel":
        start_as_channel(args)
    elif args.service_type == "tool":
        os.system("python3 ./demotool.py")
    elif args.service_type == "admin":
        os.system("python3 ./gtool.py")
    else:
        print(f"not supported service type {args.service_type}\ncheck loopchain help.\n")
        os.system("python3 ./loopchain.py -h")


def check_port_available(port):
    # Check Port is Using
    if util.check_port_using(int(port)):
        util.exit_and_msg(f"not available port({port})")


def start_as_channel(args):
    # apply default configure values
    channel = args.channel or conf.LOOPCHAIN_DEFAULT_CHANNEL
    amqp_target = args.amqp_target or conf.AMQP_TARGET
    amqp_key = args.amqp_key or conf.AMQP_KEY

    ChannelService(channel, amqp_target, amqp_key).serve()


def start_as_rest_server(args):
    peer_ip = util.get_private_ip()
    peer_port = args.port
    ServerComponents().set_resource()
    PeerServiceStub().set_stub_port(port=peer_port, IP_address=peer_ip)

    amqp_target = args.amqp_target or conf.AMQP_TARGET
    amqp_key = args.amqp_key or conf.AMQP_KEY
    api_port = int(peer_port) + conf.PORT_DIFF_REST_SERVICE_CONTAINER

    logging.info(f"Sanic rest server is running!: {api_port}")
    ServerComponents().serve(amqp_target, amqp_key, api_port)


def start_as_rest_server_rs(args):
    rs_port = args.port
    api_port = int(rs_port) + conf.PORT_DIFF_REST_SERVICE_CONTAINER

    RSServerComponents().set_resource()
    RSServerComponents().set_stub_port(port=rs_port)
    logging.info(f"Sanic rest server for RS is running!: {api_port}")
    RSServerComponents().app.run(host='0.0.0.0', port=api_port, debug=False, ssl=ServerComponents().ssl_context)


def start_as_score(args):
    # apply default configure values
    channel = args.channel or conf.LOOPCHAIN_DEFAULT_CHANNEL
    score_package = args.score_package or conf.DEFAULT_SCORE_PACKAGE
    amqp_target = args.amqp_target or conf.AMQP_TARGET
    amqp_key = args.amqp_key or conf.AMQP_KEY

    ScoreService(channel, score_package, amqp_target, amqp_key).serve()


def start_as_rs(args):
    # apply default configure values
    port = args.port or conf.PORT_RADIOSTATION
    cert = args.cert or None
    pw = None
    seed = args.seed or None
    check_port_available(int(port))

    if seed:
        try:
            seed = int(seed)
        except ValueError as e:
            util.exit_and_msg(f"seed or s opt must be int \n"
                              f"input value : {seed}")

    RadioStationService(conf.IP_RADIOSTATION, cert, pw, seed).serve(port)


def start_as_peer(args, node_type=None):
    # apply default configure values
    port = args.port or conf.PORT_PEER
    radio_station_ip = conf.IP_RADIOSTATION
    radio_station_port = conf.PORT_RADIOSTATION
    radio_station_ip_sub = conf.IP_RADIOSTATION
    radio_station_port_sub = conf.PORT_RADIOSTATION
    amqp_target = args.amqp_target or conf.AMQP_TARGET
    amqp_key = args.amqp_key or conf.AMQP_KEY

    if conf.CHANNEL_BUILTIN:
        if not amqp_key or amqp_key == conf.AMQP_KEY_DEFAULT:
            amqp_key = f"{util.get_private_ip()}:{port}"
            command_arguments.add_raw_command(command_arguments.Type.AMQPKey, amqp_key)

    check_port_available(int(port))

    if node_type is None:
        node_type = conf.NodeType.CommunityNode
    elif node_type == conf.NodeType.CitizenNode and not args.radio_station_target:
        util.exit_and_msg(f"citizen node needs subscribing peer target input")

    if args.radio_station_target:
        try:
            is_set_https = False
            if "https://" in args.radio_station_target:
                is_set_https = True
                args.radio_station_target = args.radio_station_target.split("https://")[1]
                util.logger.spam(f"args.radio_station_target({args.radio_station_target})")
            elif ':' in args.radio_station_target:
                target_list = util.parse_target_list(args.radio_station_target)
                if len(target_list) == 2:
                    radio_station_ip, radio_station_port = target_list[0]
                    radio_station_ip_sub, radio_station_port_sub = target_list[1]
                else:
                    radio_station_ip, radio_station_port = target_list[0]
                    # util.logger.spam(f"peer "
                    #                  f"radio_station_ip({radio_station_ip}) "
                    #                  f"radio_station_port({radio_station_port}) "
                    #                  f"radio_station_ip_sub({radio_station_ip_sub}) "
                    #                  f"radio_station_port_sub({radio_station_port_sub})")
            elif len(args.radio_station_target.split('.')) == 4:
                radio_station_ip = args.radio_station_target
            elif len(args.radio_station_target.split('.')) >= 2:
                is_set_https = True
            else:
                raise Exception("Invalid IP format")

            if is_set_https:
                radio_station_ip = args.radio_station_target
                radio_station_port = 443
                util.logger.spam(f"start_as_peer:radio_station_ip {radio_station_ip}")

        except Exception as e:
            util.exit_and_msg(f"'-r' or '--radio_station_target' option requires "
                              f"[IP Address of Radio Station]:[PORT number of Radio Station], "
                              f"or just [IP Address of Radio Station] format. error({e})")

    # run peer service with parameters
    logging.info(f"loopchain peer run with: port({port}) "
                 f"radio station({radio_station_ip}:{radio_station_port})")

    PeerService(
        radio_station_ip=radio_station_ip,
        radio_station_port=radio_station_port,
        node_type=node_type
    ).serve(
        port=port,
        agent_pin=args.agent_pin,
        amqp_target=amqp_target,
        amqp_key=amqp_key
    )
