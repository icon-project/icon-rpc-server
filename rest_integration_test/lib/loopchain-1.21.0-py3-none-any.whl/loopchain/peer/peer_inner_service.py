# Copyright 2017 theloop Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import TYPE_CHECKING

from loopchain.message_queue import *
from loopchain import utils as util
from loopchain.utils.message_queue import StubCollection

if TYPE_CHECKING:
    from loopchain.peer import PeerService


class PeerInnerTask:
    def __init__(self, peer_service: 'PeerService'):
        self._peer_service = peer_service

    @message_queue_task
    async def hello(self):
        return 'peer_hello'

    @message_queue_task
    async def get_channel_infos(self):
        return self._peer_service.channel_infos

    @message_queue_task
    async def get_channel_info_detail(self, channel_name):
        channels_info = self._peer_service.channel_infos

        return \
            self._peer_service.peer_port, self._peer_service.peer_target, self._peer_service.rest_target, \
            self._peer_service.radio_station_target, self._peer_service.peer_id, self._peer_service.group_id, \
            self._peer_service.node_type.value, channels_info[channel_name]['score_package']

    @message_queue_task
    async def stop_outer(self):
        self._peer_service.service_stop()
        return "stop outer"

    @message_queue_task
    async def start_outer(self):
        self._peer_service.run_common_service()
        return "start outer"

    @message_queue_task(type_=MessageQueueType.Worker)
    async def stop(self, message):
        logging.info(f"peer_inner_service:stop")
        for stub in StubCollection().channel_stubs.values():
            await stub.async_task().stop(message)

        util.exit_and_msg(message)


class PeerInnerService(MessageQueueService[PeerInnerTask]):
    TaskType = PeerInnerTask


class PeerInnerStub(MessageQueueStub[PeerInnerTask]):
    TaskType = PeerInnerTask
