# Copyright 2017 theloop Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Validate Strategy for Tx and Signature"""

import abc
import binascii
import hashlib
import json
import logging
import pickle
import re
import traceback
from secp256k1 import PrivateKey, PublicKey

import loopchain.utils as util
from loopchain import configure as conf
from loopchain.blockchain import Transaction
from loopchain.protos import loopchain_pb2
from loopchain.tools.signature_helper import PublicVerifierContainer


class TxValidateStrategy(metaclass=abc.ABCMeta):
    @staticmethod
    def create(send_tx_type):
        if send_tx_type == conf.SendTxType.pickle:
            return PickleValidateStrategy()
        elif send_tx_type == conf.SendTxType.json:
            return JsonValidateStrategy()
        elif send_tx_type == conf.SendTxType.icx:
            return IconValidateStrategy()
        else:
            raise Exception

    @classmethod
    @abc.abstractclassmethod
    def validate(cls, tx: Transaction) -> bool:
        pass

    @classmethod
    @abc.abstractmethod
    def validate_dumped_tx_message(cls, tx_dumped, channel) -> Transaction:
        pass

    @classmethod
    @abc.abstractmethod
    def validate_dumped_tx(cls, tx_dumped: dict, channel):
        pass

    @classmethod
    @abc.abstractmethod
    def restore(cls, tx_dumped: str, channel):
        pass

    @classmethod
    @abc.abstractmethod
    def load_dumped_tx(cls, tx_message: loopchain_pb2.TxSend):
        pass


class IconValidateStrategy(TxValidateStrategy):
    __pri = PrivateKey()
    __ctx_cached = __pri.ctx

    SEND_TX = "icx_sendTransaction"

    @classmethod
    def validate_dumped_tx_message(cls, tx_json, channel):
        tx = cls.restore(tx_json, channel)
        if tx is not None:
            if cls.validate(tx):
                return tx
        return None

    @classmethod
    def validate(cls, tx: Transaction):
        try:
            if cls.__validate_icx_params(tx.icx_origin_data, tx.tx_hash):
                if cls.__validate_icx_signature(tx.tx_hash, tx.signature, tx.icx_origin_data['from']):
                    return True
            return False
        except Exception as e:
            logging.warning(f"tx {tx.tx_hash} validate fail {e}")
            traceback.print_exc()
            return False

    @classmethod
    def validate_dumped_tx(cls, tx_json: dict, channel):
        return cls.validate_dumped_tx_message(json.dumps(tx_json), channel)

    @classmethod
    def restore(cls, tx_json: str, channel):
        tx = Transaction()
        tx.put_meta(Transaction.SEND_TX_TYPE_KEY, conf.SendTxType.icx)
        tx.put_meta(Transaction.CHANNEL_KEY, channel)
        tx.put_meta(Transaction.METHOD_KEY, cls.SEND_TX)
        if cls.__init_icx_tx(tx_json, tx):
            return tx
        else:
            return None

    @classmethod
    def load_dumped_tx(cls, tx_message: loopchain_pb2.TxSend):
        return tx_message.tx_json

    @classmethod
    def __init_icx_tx(cls, icx_dumped_data: str, tx: Transaction):
        icx_origin_data = json.loads(icx_dumped_data)
        if tx.set_icx_origin_data(icx_origin_data, icx_dumped_data):
            return True
        return False

    @classmethod
    def __validate_icx_params(cls, icx_origin_data, tx_hash):
        if not util.is_hex(tx_hash):
            logging.info(f"{tx_hash} is invalid tx_hash")
            return False
        if not cls.__is_address(icx_origin_data['from']):
            return False
        expect_tx_hash = cls.__generate_icx_hash(icx_origin_data)
        if tx_hash != expect_tx_hash:
            logging.info(f"tx tx_hash validate fail expect : {expect_tx_hash} input : {tx_hash}")
            return False
        return True

    @classmethod
    def __validate_icx_signature(cls, tx_hash, signature, address) -> bool:
        """

        :param tx_hash:
        :param signature:
        :param address:
        :return:
        """
        try:
            origin_signature, recover_code = signature[:-1], signature[-1]
            recoverable_sig = cls.__pri.ecdsa_recoverable_deserialize(origin_signature, recover_code)
            pub = cls.__pri.ecdsa_recover(binascii.unhexlify(tx_hash),
                                          recover_sig=recoverable_sig,
                                          raw=True,
                                          digest=hashlib.sha3_256)

            public_key = PublicKey(pub, ctx=cls.__ctx_cached)
            hash_pub = hashlib.sha3_256(public_key.serialize(compressed=False)[1:]).hexdigest()
            expect_address = f"hx{hash_pub[-40:]}"
            if expect_address != address:
                logging.info(f"tx address validate fail expect : {expect_address} input : {address}")
                return False
            return True
        except Exception as e:
            logging.error(f"tx signature validate fail cause {e}")
            traceback.print_exc()
            return False

    @classmethod
    def __is_address(cls, address) -> bool:
        if address[:2] != 'hx':
            logging.info(f"address {address} must have header hx")
            return False
        if re.fullmatch(r"^[0-9a-f]{40}$", address[2:] or "") is None:
            logging.info(f"address {address} address contents data must have : ")
            return False
        return True

    @classmethod
    def __get_version(cls, icx_origin_data):
        if 'version' in icx_origin_data and icx_origin_data['version'] == hex(conf.ApiVersion.v3):
            return conf.ApiVersion.v3
        return conf.ApiVersion.v2

    @classmethod
    def __get_tx_hash_key(cls, icx_origin_data):
        if cls.__get_version(icx_origin_data) == conf.ApiVersion.v3:
            tx_hash_key = "txHash"
        else:
            tx_hash_key = "tx_hash"
        return tx_hash_key

    @classmethod
    def __generate_icx_hash(cls, icx_origin_data):
        tx_hash_key = cls.__get_tx_hash_key(icx_origin_data)
        return util.generate_icx_hash(icx_origin_data, tx_hash_key)


class PickleValidateStrategy(TxValidateStrategy):
    @classmethod
    def validate_dumped_tx(cls, tx_pickle: dict, channel):
        pass

    @classmethod
    def validate_dumped_tx_message(cls, tx_pickle, channel):
        try:
            tx = cls.restore(tx_pickle, channel)
            if cls.validate(tx):
                return tx
            return None
        except Exception as e:
            logging.debug(f"tx validate fail cause {e}")
            traceback.print_exc()
            return None

    @classmethod
    def validate(cls, tx: Transaction):
        try:
            if Transaction.generate_transaction_hash(tx) != tx.get_tx_hash():
                PickleValidateStrategy.__logging_tx_validate("hash validate fail", tx)
                return False

            # tx = self.__tx_validator()

            # Get Cert Verifier for signature verify
            public_verifier = PublicVerifierContainer.get_public_verifier(tx.meta[Transaction.CHANNEL_KEY],
                                                                          tx.public_key)

            # Signature Validate
            if public_verifier.verify_hash(tx.get_tx_hash(), tx.signature):
                return True
            else:
                PickleValidateStrategy.__logging_tx_validate("signature validate fail", tx)
                return False

        except Exception as e:
            PickleValidateStrategy.__logging_tx_validate("signature validate fail", tx)
            return False

    @classmethod
    def restore(cls, tx_pickle: bytes, channel):
        return pickle.loads(tx_pickle)

    @classmethod
    def load_dumped_tx(cls, tx_message: loopchain_pb2.TxSend):
        return tx_message.tx

    @staticmethod
    def __logging_tx_validate(fail_message, tx):
        logging.exception(f"validate tx fail "
                          f"\ntx hash : {tx.get_tx_hash()}"
                          f"\ntx meta: {tx.meta}"
                          f"\ntx data: {tx.get_data()}"
                          f"\ntx signature: {tx.signature}"
                          f"\ncaused by: {fail_message}")


class JsonValidateStrategy(TxValidateStrategy):
    @classmethod
    def validate_dumped_tx(cls, tx_json: dict, channel):
        pass

    @classmethod
    def validate_dumped_tx_message(cls, tx_json, channel):
        tx = cls.restore(tx_json, channel)
        return tx

    @classmethod
    def validate(cls, tx: Transaction):
        return True

    @classmethod
    def restore(cls, tx_json: str, channel):
        return Transaction.json_loads(tx_json)

    @classmethod
    def load_dumped_tx(cls, tx_message: loopchain_pb2.TxSend):
        return tx_message.tx_json
