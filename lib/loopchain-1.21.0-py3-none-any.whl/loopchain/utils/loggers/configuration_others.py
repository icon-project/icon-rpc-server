# Copyright [theloop]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
from loopchain import configure as conf
from loopchain.utils.loggers.configuration import LogConfiguration

preset_others = LogConfiguration()
preset_others.log_format = conf.LOG_FORMAT_DEBUG
preset_others.log_level = logging.WARNING
preset_others.log_color = True
preset_others.log_file_path = conf.LOG_FILE_PATH
preset_others.log_monitor = conf.MONITOR_LOG
preset_others.log_monitor_host = conf.MONITOR_LOG_HOST
preset_others.log_monitor_port = conf.MONITOR_LOG_PORT


def update_other_loggers():
    logger_pika = logging.getLogger('pika')
    preset_others.update_logger(logger_pika)

    logger_aio_pika = logging.getLogger('aio_pika')
    preset_others.update_logger(logger_aio_pika)

    logger_sanic_access = logging.getLogger('sanic.access')
    preset_others.update_logger(logger_sanic_access)

    logger_json_rpc_client_request = logging.getLogger('jsonrpcclient.client.request')
    preset_others.update_logger(logger_json_rpc_client_request)

    logger_json_rpc_client_response = logging.getLogger('jsonrpcclient.client.response')
    preset_others.update_logger(logger_json_rpc_client_response)
